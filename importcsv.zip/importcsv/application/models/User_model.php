<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model{
    
    function __construct() {
        $this->table = 'course_tbl';
    }
    
  
    function getRows($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
        
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
        
        return $result;
    }
    
    public function insert($data = array()) {
        if(!empty($data)){
            $insert = $this->db->insert($this->table, $data);
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }

    public function query($query){

         $this->db->query($query);

        return true;
        // echo '<script>windows.histroy.back();</script>';
    }
    
}