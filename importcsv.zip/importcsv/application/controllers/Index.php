<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Index extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('form_validation');
        $this->load->helper('file');
        ini_set('max_execution_time', 0);

    }
    
    public function index(){
        $data = array();
        
        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        
        $data['course_info'] = $this->User_model->getRows();
        $this->load->view('index', $data);
    }
    
    public function upload(){
        $this->load->view('upload');

    }

    public function senddata(){
         // print_r($_POST);die();
        $data = $_POST['file'];
        $handle = fopen($data, "r");
        $test = file_get_contents($data);
    if ($handle) {
    $counter = 0;
    $sql ="INSERT INTO course_tbl(id,course_name,course_code,course_info) VALUES ";
    while (($line = fgets($handle)) !== false) {
      $sql .= "($line),";
      $counter++;
    }
    $sql = substr($sql, 0, strlen($sql) - 1);
    // print_r($sql);die();
     if ($this->User_model->query($sql) === TRUE) {
    } else {
     }
    fclose($handle);
} else {  
} 

  //unlink CSV file once already imported to DB to clear directory
    // unlink($data);
   // redirect('Index/index',refresh');
// echo '<script>windows.history.back()</script>';
 

    }


}