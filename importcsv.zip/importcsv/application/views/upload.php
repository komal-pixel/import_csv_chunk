<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.1/jquery.js"></script>
<script>
//Declaration of function that will insert data into database
 function senddata(filename){
        var file = filename;
        $.ajax({
            type: "POST",
            url: "<?= site_url('Index/senddata'); ?>",
            data: {file},
            async: true,
            success: function(html){
                $("#result").html(html);
            }
        })
        }
 </script>
<?php
$csv = array();
$batchsize = 1000; //split huge CSV file by 1,000, you can modify this based on your needs
if($_FILES['file']['error'] == 0){
    $name = $_FILES['file']['name'];
    $ext1 = explode('.', $_FILES['file']['name']);
    // print_r($ext);die();
    $ext = $ext1[1];
    $tmpName = $_FILES['file']['tmp_name'];
    if($ext === 'csv'){ //check if uploaded file is of CSV format
        if(($handle = fopen($tmpName, 'r')) !== FALSE) {
            set_time_limit(0);
            $row = 0;
            while(($data = fgetcsv($handle)) !== FALSE) {
                $col_count = count($data);
                //splitting of CSV file :
                if ($row % $batchsize == 0):
                    $file = fopen("minpoints$row.csv","w");
                endif;
                $csv[$row]['col1'] = $data[0];
                $csv[$row]['col2'] = $data[1];
                $csv[$row]['col3'] = $data[2];
                $csv[$row]['col4'] = $data[3];

                $first = $data[0];
                $second = $data[1];
                $third  = $data[2];
                $fourth = $data[3];
                // print_r($fourth);die();
                $json = "'$first', '$second','$third','$fourth'";
                // print_r($file);die();
                fwrite($file,$json.PHP_EOL);
                //sending the splitted CSV files, batch by batch...
                   if ($row % $batchsize == 0):
                    echo "<script> senddata('minpoints$row.csv'); </script>";
                endif;
                $row++; 
            }
            fclose($file);
            fclose($handle);

        }
    }
    else
    {
        echo "Only CSV files are allowed.";
    }
    //alert once done.
     // echo "<script> index(); </script>";
}

?>